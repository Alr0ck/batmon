<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Battery Monitor</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link rel="shortcut icon" href="../assets/bat/img/favicon.ico"/>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <!-- global css -->
    <link type="text/css" rel="stylesheet" href="../assets/bat/css/app.css"/>
    <!-- end of global css -->
    <!--page level css -->
    <link rel="stylesheet" href="../assets/bat/vendors/swiper/css/swiper.min.css">
    <link href="../assets/bat/vendors/nvd3/css/nv.d3.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="../assets/bat/vendors/lcswitch/css/lc_switch.css">
    <link rel="stylesheet" type="text/css" href="../assets/bat/css/custom.css">
    <link rel="stylesheet" href="../assets/bat/css/custom_css/skins/skin-default.css" type="text/css" id="skin"/>
    <link href="../assets/bat/css/custom_css/dashboard1.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/bat/css/custom_css/dashboard1_timeline.css" rel="stylesheet"/>

    <!-- Ajax -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- Datatables -->
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">

    <!-- Button Exports -->
    <script src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>        
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css">

    <script type="text/javascript">
        $(document).ready(function() {
            var table = $('#data-table').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                {
                    extend: 'copyHtml5',
                    exportOptions: {
                     columns: ':contains("Office")'
                    }
                }, 'csv', 'excel', 'pdf', 'print'
                ],
                ajax: "<?php echo base_url(); ?>" + "battery/get_data_table",
                ordering: true,
                paging: true,
                searching: true,
                "aoColumns": [
                    { "data": "no" },
                    { "data": "detail"},
                    { "data": "date" },
                    { "data": "time" },
                    { "data": "voltage" },
                    { "data": "status"}
                ]
            } );

            setInterval(function() {
                table.ajax.reload( null, false ); //agar pagging tidak refresh
            }, 5000);
        });
    </script>
    <!--end of page level css-->
</head>
<body class="skin-default">
<!-- <div class="preloader">
    <div class="loader_img"><img src="assets/bat/img/loader.gif" alt="loading..." height="64" width="64"></div>
</div> -->
<!-- header logo: style can be found in header-->
<header class="header">
    <nav class="navbar navbar-static-top" role="navigation">
        <a href="<?php echo base_url(); ?>" class="logo">
            <!-- Add the class icon to your logo image or logo icon to add the marginin -->
            <img src="../assets/bat/img/logo.png" alt="logo"/>
        </a>
        <div>
            <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button"> <i
                    class="fa fa-fw ti-menu"></i>
            </a>
        </div>
        <!--<script src="../assets/bat/js/app.js" type="text/javascript"></script>-->
    </nav>
</header>
<div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="left-side sidebar-offcanvas">
        <!-- sidebar: style can be found in sidebar-->
        <section class="sidebar">
            <div id="menu" role="navigation">
                <div class="nav_profile">
                    <div class="media profile-left">
                        <a class="pull-left profile-thumb" href="#">
                            <img src="../assets/bat/img/authors/avatar1.jpg" class="img-circle" alt="User Image"></a>
                        <div class="content-profile">
                            <h4 class="media-heading">Alfiyan</h4>
                        </div>
                    </div>
                </div>
                <ul class="navigation">
                    <li>
                        <a href="<?php echo base_url(); ?>">
                            <i class="menu-icon ti-location-pin"></i>
                            <span>Maps</span>
                        </a>
                    </li>
                    <li class="active" id="active">
                        <a href="<?php echo base_url().'battery/data_monitor'; ?>">
                            <i class="menu-icon ti-desktop"></i>
                            <span>Data Monitors</span>
                        </a>
                    </li>
                    <li class="menu-dropdown">
                        <a href="#">
                            <i class="menu-icon ti-settings"></i>
                            <span>Settings</span>
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="sub-menu">
                            <li>
                                <a href="<?php echo base_url().'battery/add_hardware' ?>">
                                    <i class="fa fa-fw ti-map"></i> Locations
                                </a>
                            </li>
                        </ul>
                        <ul class="sub-menu">
                            <li>
                                <a href="<?php echo base_url().'battery/setting_parameters' ?>">
                                    <i class="fa fa-fw ti-map"></i> Parameters
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- / .navigation --> </div>
            <!-- menu --> </section>
        <!-- /.sidebar --> </aside>
    <aside class="right-side">

        <section class="content-header">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-5 col-xs-8">
                    <div class="header-element">
                        <h3>Clear/
                            <small>Dashboard</small>
                        </h3>
                    </div>
                </div>
                <div class="col-lg-4 col-lg-offset-2 col-md-6 col-sm-7 col-xs-4">
                    <div class="header-object">
                        <span class="option-search pull-right hidden-xs">
                            <span class="search-wrapper">
                                <input type="text" placeholder="Search here"><i class="ti-search"></i>
                            </span>
                        </span>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <div class="flip">
                        <div class="widget-bg-color-icon card-box front">
                            <div class="text-left">
                                <h3 class="text-dark"><b>Data Monitors / </b> <a href="<?php echo base_url().'battery/request'; ?>"><button class="btn btn-primary btn-sm">Request</button></a></h3>

                                <table id="data-table" class="display" cellspacing="1" width="100%">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Details</th>
                                            <th>Date</th>
                                            <th>Time</th>
                                            <th>Voltage (V)</th>
                                            <th>Percentage (%)</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="background-overlay"></div>
        </section>
        <!-- /.content --> </aside>
    <!-- /.right-side --> </div>
<!-- ./wrapper -->
<!-- global js -->
<div id="qn"></div>
<!--<script src="../assets/bat/js/app.js" type="text/javascript"></script>-->
<!-- end of global js -->

<!-- end of page level js -->
</body>

</html>