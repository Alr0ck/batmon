<html>
	<title>Battery Monitor</title>
	<head>
		<!-- <link rel="stylesheet" href="assets/css/bootstrap.min.css"> -->
		<link rel="stylesheet" href="assets/css/batery.css">
		<link rel="stylesheet" href="assets/css/nav.css">
		<link rel="stylesheet" href="assets/css/bootstrap-cdn.css">
		<!-- <script src="assets/js/bootstrap.min.js"></script> -->

		<!-- Ajax -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<!-- Datatables -->
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">

		<!-- Button Exports -->
		<script src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
		<script src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.flash.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
		<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script>
		<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script>
		<script src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.html5.min.js"></script>
		<script src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>		
		<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css">

		<!-- Chart -->
		<script src="assets/js/chart.js"></script>

		<script type="text/javascript">
			$(document).ready(function() {

				$(document).ready(function(){
					//chart
					var count = 10;

					var data = {
						labels : <?php echo $labels; ?>,
						datasets : [
							{
								fillColor : "rgba(151,187,205,0.5)",
								strokeColor : "rgba(151,187,205,1)",
								pointColor : "rgba(151,187,205,1)",
								pointStrokeColor : "#fff",
								data : <?php echo $datas; ?>
							}
						]
					}
					  
					var optionsAnimation = {
						//Boolean - If we want to override with a hard coded scale
						scaleOverride : false,
						//** Required if scaleOverride is true **
						//Number - The number of steps in a hard coded scale
						scaleSteps : 10,
						//Number - The value jump in the hard coded scale
						scaleStepWidth : 10,
						//Number - The scale starting value
						scaleStartValue : 0
					}

					// Not sure why the scaleOverride isn't working...
					var optionsNoAnimation = {
						animation : false,
						//Boolean - If we want to override with a hard coded scale
						scaleOverride : true,
						//** Required if scaleOverride is true **
						//Number - The number of steps in a hard coded scale
						scaleSteps : 20,
						//Number - The value jump in the hard coded scale
						scaleStepWidth : 10,
						//Number - The scale starting value
						scaleStartValue : 0
					}

					//Get the context of the canvas element we want to select
					var ctx = document.getElementById("myChart").getContext("2d");
					var optionsNoAnimation = {animation : true};
					var myNewChart = new Chart(ctx);
					myNewChart.Line(data, optionsNoAnimation);	
				});

				$(document).ready(function() {
					var table = $('#data-table').DataTable( {
						dom: 'Bfrtip',
						buttons: [
						{
			                extend: 'copyHtml5',
			                exportOptions: {
			                 columns: ':contains("Office")'
			                }
			            }, 'csv', 'excel', 'pdf', 'print'
						],
						ajax: "<?php echo base_url(); ?>" + "monitor/get_data_table",
						ordering: true,
						paging: true,
    					searching: false,
						"aoColumns": [
							{ "data": "no" },
							{ "data": "date" },
							{ "data": "time" },
							{ "data": "voltage" }
						]
					} );
					
					setInterval(function() {
						table.ajax.reload( null, false ); //agar pagging tidak refresh
						// $('#myChart').load('#myChart');
					}, 2000);
				} );

                setInterval(function()
				{ 
					var res;
				    jQuery.ajax({
                        type: "GET",
                        url: "<?php echo base_url(); ?>" + "monitor/get_info",
                        dataType: 'json',
                        success: function(res) {
                            if (res)
                            {
                                jQuery("div#id").html(res.id);

                                switch(res.status){
                                	case "success"	: 	jQuery("div#datetimelatest").html('<label class="label label-success"><span class="glyphicon glyphicon-time"></span> '+res.datetimelatest+'</label>');
						                                jQuery("div#voltage").html('<label class="label label-success"><span class="glyphicon glyphicon-flash"></span> '+res.voltage+' V</label>');
						                                jQuery("div#percent").html('<div class="progress"><div class="progress-bar progress-bar-success" role="progressbar" style="width:'+res.percent+'%" >'+res.percent+'%</div></div>');
						                                break;
	                                case "warning"	: 	jQuery("div#datetimelatest").html('<label class="label label-warning"><span class="glyphicon glyphicon-time"></span> '+res.datetimelatest+'</label>');
						                                jQuery("div#voltage").html('<label class="label label-warning"><span class="glyphicon glyphicon-flash"></span> '+res.voltage+' V</label>');
						                                jQuery("div#percent").html('<div class="progress"><div class="progress-bar progress-bar-warning" role="progressbar" style="width:'+res.percent+'%" >'+res.percent+'%</div></div>');
						                                break;
						            case "danger"	: 	jQuery("div#datetimelatest").html('<label class="label label-danger"><span class="glyphicon glyphicon-time"></span> '+res.datetimelatest+'</label>');
						                                jQuery("div#voltage").html('<label class="label label-danger"><span class="glyphicon glyphicon-flash"></span> '+res.voltage+' V</label>');
						                                jQuery("div#percent").html('<div class="progress"><div class="progress-bar progress-bar-danger" role="progressbar" style="width:'+res.percent+'%" >'+res.percent+'%</div></div>');
                                }

                                jQuery("div#datetimenow").html('<label class="label"><span class="glyphicon glyphicon-time"></span> '+res.datetimenow+'</label>');
                            }
                        }
                    });
				}, 1000);
            });
		</script>
	</head>
	<body>
		<!-- <div id="labelsss"></div> -->
		<div class="container">
		    <div class="page-header">
		        <h1><?php echo $title; ?>.<span class="pull-right label label-default"><div class="pull-right" id="datetimenow"></div></span></h1>
		    </div>
		    <div class="row">
		    	<div class="col-md-12">
		            <div class="panel with-nav-tabs panel-info">
		                <div class="panel-heading">
	                        <ul class="nav nav-tabs">
	                            <li class="active"><a href="#tab1warning" data-toggle="tab">Monitor</a></li>
	                            <li><a href="#tab2warning" data-toggle="tab">Logger</a></li>
	                            <li><a href="#tab3warning" data-toggle="tab">Graphic</a></li>
	                            <li class="dropdown">
	                                <a href="#" data-toggle="dropdown">Settings <span class="caret"></span></a>
	                                <ul class="dropdown-menu" role="menu">
	                                    <li><a href="#tab4warning" data-toggle="tab">Parameters</a></li>
	                                    <!-- <li><a href="#tab5warning" data-toggle="tab">Warning 5</a></li> -->
	                                </ul>
	                            </li>
	                        </ul>
		                </div>
		                <div class="panel-body">
		                    <div class="tab-content">
		                        <div class="tab-pane fade in active" id="tab1warning">
	                        		<div class="offer-content">
										<div class="row">
											<div class="col-md-6">
												<div class="panel panel-info">
											  		<div class="panel-body">
											  			<div class="row">
													<div class="col-md-6">
														Voltage <p><div id="voltage"></div></p>
															</div>
															<div class="col-md-6 text-right">
																Data Update <p><div id="datetimelatest"></div></p>
															</div>
														</div>
														<br>
													 		Battery Status
														<br> 
														<p>
					                       					<div id="percent"></div>
							                   			</p>	
											  		</div>
												</div>
					                   		</div>
					                   		<div class="col-md-6">
												<div class="panel panel-info">
											  		<div class="panel-body">
											  			<b><u>Colors Information Battery Status : </u></b> <br><br>
											  			<i>
											  			<label class="label label-success"> </label>&nbsp;Battery Status > 60%
											  			<br><br>
											  			<label class="label label-warning"> </label>&nbsp;Battery Status < 60%
										  				<br><br>
										  				<label class="label label-danger"> </label>&nbsp;Battery Status < 20%
										  				</i>
										  			</div>
												</div>
					                   		</div>
				                   		</div>
									</div>
		                        </div>
		                        <div class="tab-pane fade" id="tab2warning">
		                        	<div class="panel panel-info">
								  		<div class="panel-body">
				                        	<table id="data-table" class="display" cellspacing="1" width="100%">
										        <thead>
										            <tr>
										                <th>No</th>
										                <th>Date</th>
										                <th>Time</th>
										                <th>Voltage</th>
										            </tr>
										        </thead>
										    </table>
									    </div>
									</div>
		                        </div>
		                        <div class="tab-pane fade" id="tab3warning">
		                        	<div class="panel panel-info">
								  		<div class="panel-body">
								  			<div class="row">
									  			<div class="col-md-6">
								  					<h4>Voltage Battery</h4>
									  			</div>
									  			<div class="col-md-6">
									  				<input id="btn" type="button" class="btn btn-default pull-right" value="Refresh" onclick="return btn_onclick()" />
													<script language="javascript" type="text/javascript">
													function btn_onclick() 
													{
													    window.location.href = "<?php echo base_url(); ?>";
													}
													</script>
									  			</div>
								  			</div>
		                        			<canvas id="myChart" width="1100" height="300"></canvas>
		                        		</div>
		                        	</div>
		                        </div>
		                        <div class="tab-pane fade" id="tab4warning">
		                        	<div class="panel panel-info">
								  		<div class="panel-body">
								  			<div class="row">
								  				<div class="col-md-6">
										  			<form action="<?php echo base_url().'update_max_volatege' ?>" method="post">
										  				<div class="form-group">
															<label for="maxvoltage">Maximum Voltage :</label>
															<input type="text" class="form-control" id="maxvoltage" value="3.4 Volt">
															<input type="button" class="btn btn-default pull-right" value="Set" />
														</div>
										  			</form>
									  			</div>
								  			</div>
								  		</div>
							  		</div>
		                        </div>
		                        <div class="tab-pane fade" id="tab5warning">Warning 5</div>
		                    </div>
		                </div>
		            </div>
		        </div>
			</div>
		</div>
	</body>
</html>