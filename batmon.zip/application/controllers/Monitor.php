<?php
	class Monitor extends CI_Controller{
		
		function __construct(){
			parent::__construct();
			$this->load->model('m_monitor');
		}

		function index(){
			$data["title"] = "Battery Monitor";
			$data['labels'] = $this->m_monitor->get_data_chart("labels",15);
			$data['datas'] 	= $this->m_monitor->get_data_chart("datas",15);
			$this->load->view('v_monitor',$data);
		}

		function datetime($input){
			date_default_timezone_set('Asia/Jakarta');
		
			$date = date("Y-m-d");
			$time = date("H:i:s");
			if($input == "date"){
				return $date;
			}
			else if($input == "time"){
				return $time;
			}
		}

		function send_data(){
			$voltage = $this->input->get('voltage');
			$date = $this->datetime('date');
			$time = $this->datetime('time');

			$data = array(
				'date' => $date,
				'time' => $time,
				'voltage' => $voltage
			);

			$this->m_monitor->add_data($data);
		}

		function get_info(){
			$dbData = $this->m_monitor->get_data_latest();
			$id = $dbData[0];
			$date = $dbData[1];
			$time = $dbData[2];
			$voltage = $dbData[3];

			///*summary
			///percent battery = (value_sensor / max_voltage_battery) * 100
			///*end summary
			$voltageMax = 5.0;
			if($voltage > $voltageMax){
				$voltage = $voltageMax;
			}
			$percent = ($voltage / $voltageMax) * 100;
			
			if($percent <= 20){
				$status = "danger";
			}
			else if($percent <= 60){
				$status = "warning";
			}
			else if($percent <= 100){
				$status = "success";
			}

			$data = array(
				'id' => $id,
				'datetimelatest' => $date." ".$time,
				'voltage' => $voltage,
				'percent' => $percent,
				'status' => $status,
				'datetimenow' => $this->datetime('date')." ".$this->datetime('time')
			);

			echo json_encode($data);
		}

		function get_data_table(){
			$dbData = $this->m_monitor->get_data_all();
			echo $dbData;
		}

		function get_line(){
			$dbData = $this->m_monitor->get_data_line(15);
			echo json_encode($dbData);
		}

		function update_max_voltage(){
			$id = 1;
			$maxVoltage = $this->input->post('maxvoltage');
			$data = array(
				'maxvoltage' => $maxVoltage
			);
			$this->m_monitor->update_maxvoltage($id,$data);
		}

	}