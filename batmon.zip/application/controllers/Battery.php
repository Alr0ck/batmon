<?php
	class Battery extends CI_Controller{
		
		function __construct(){
			parent::__construct();
			$this->load->library('googlemaps');
			$this->load->model('m_battery');
		}

		function index(){
			//$data["title"] = "Battery Monitor";
			
			$config['center'] = '-7.8934, 112.664';
			$config['zoom'] = '11';
			$this->googlemaps->initialize($config);

			$data = array();
			$query = $this->db->query("SELECT * FROM location ORDER BY id ASC");

			if($query->row_array()){
				foreach($query->result() as $row){
					$id_battery = $row->id_battery;
					$query2 = $this->db->query("SELECT * FROM data2 WHERE id_battery = '$id_battery'");
					if($query2->row_array()){
						foreach($query2->result() as $row2){
							$tanggal		= $row2->date;
							$waktu			= $row2->time;
							$voltage		= $row2->voltage;
							$precentage		= $row2->precentage;		
						} 
					}
					$id_battery		= $row->id_battery;
					$lat 			= $row->latitude;
					$long 			= $row->longitude;

					$desk = "<b>[Battery ".$id_battery."]</b></br>Battery Precentages : ".$precentage." %</br>Battery Voltage : ".$voltage." Volt</br>Date : ".$tanggal."</br>Time : ".$waktu."</br>Latitude : ".$lat."</br>Longitude : ".$long;
					$marker = array();
					$marker['position'] = $lat.",".$long;
					$marker['infowindow_content'] = $desk;
					$marker['animation'] = 'DROP';
					$this->googlemaps->add_marker($marker);
				}
			}

			$data['map'] = $this->googlemaps->create_map();

			$this->load->view("v_map",$data);
		}

		function get_data_table(){
			$dbData = $this->m_battery->get_data_monitor();
			echo $dbData;
		}

		function data_monitor(){
			$this->load->view("v_data_monitor");
		}

// 		function detail(){
// 			$id_battery = $this->input->get('id');
// 			$data = $this->m_battery->get_data_detail($id_battery);
// 			echo $data;	
// 		}

        function detail(){
			$data['id_battery'] = $this->input->get('id');
			$this->load->view('v_data_detail',$data);
		}

		function setting_parameters(){
			$dbData = $this->m_battery->get_max_voltage();
			$data['maxvoltage'] = $dbData[0];
			$this->load->view("v_setting_parameters",$data);
		}

		function update_max_voltage(){
			$id = 1;
			$maxVoltage = $this->input->post('maxvoltage');
			$data = array(
				'maxvoltage' => $maxVoltage
			);
			$this->m_battery->update_maxvoltage($id,$data);

			$dbData = $this->m_battery->get_max_voltage();
			$data['maxvoltage'] = $dbData[0];
			$this->load->view("v_setting_parameters",$data);
		}

		//backend communication

		function datetime($input){
			date_default_timezone_set('Asia/Jakarta');
		
			$date = date("Y-m-d");
			$time = date("H:i:s");
			if($input == "date"){
				return $date;
			}
			else if($input == "time"){
				return $time;
			}
		}

		function send_data(){
			$id_battery = $this->input->get('battery');
			$voltage = $this->input->get('voltage');
			$date = $this->datetime('date');
			$time = $this->datetime('time');

			///*summary
			///percent battery = (value_sensor / max_voltage_battery) * 100
			///*end summary
			$maxV = $this->m_battery->get_max_voltage();
			$voltageMax = $maxV[0];
			if($voltage > $voltageMax){
				$voltage = $voltageMax;
			}
			$percent = ($voltage / $voltageMax) * 100;
            $percent = number_format($percent,2,".","");
			$data = array(
				'date' 			=> $date,
				'time' 			=> $time,
				'voltage' 		=> $voltage,
				'precentage' 	=> $percent
			);

			$this->m_battery->update_data_temporary($id_battery,$data);
		}

		function request(){
			$this->m_battery->grab_data();
			$this->load->view("v_data_monitor");
		}
		
		//add new hardware

		function get_data_location(){
			$dbData = $this->m_battery->get_data_location();
			echo $dbData;
		}

		function add_hardware(){
			$this->load->view('v_add_hardware');
		}

		function add_location(){
			$id_battery = $this->input->post('idbattery');
			$latitude 	= $this->input->post('latitude');
			$longitude 	= $this->input->post('longitude');
			$date = "-";
			$time = "-";

			$data_temporary = array(
				'id_battery'	=> $id_battery,
				'date'			=> $date,
				'time'			=> $time,
				'voltage'		=> 0,
				'precentage'	=> 0
			);

			$data_location = array(
				'id_battery' 	=> $id_battery,
				'latitude'		=> $latitude,
				'longitude'		=> $longitude
			);

			$this->m_battery->add_data('temporary',$data_temporary);
			$this->m_battery->add_data('data2',$data_temporary);
			$this->m_battery->add_data('location',$data_location);
			$this->load->view('v_add_hardware');
		}

	}