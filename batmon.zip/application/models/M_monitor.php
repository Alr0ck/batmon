<?php

	class M_monitor extends CI_Model{

		function add_data($data){
			$this->db->insert('data',$data);
		}

		function update_maxvoltage($id,$data){
			$this->db->where('id',$id);
			$this->db->update('setting',$data);
		}

		function get_data_latest(){
			$data = array();
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC LIMIT 1");
			foreach($query->result() as $row){
				$data[0] = $row->id;
				$data[1] = $row->date;
				$data[2] = $row->time;
				$data[3] = $row->voltage;
				$data[4] = $row->isdeleted;
			}
			return $data;
		}

		function get_data_all(){
			$i = 0;
			$data = array();
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC");
			
			$jsonResult = '{"data" : ';
			foreach($query->result() as $row){
				$json_data[$i] = array(
					"no"		=> $i+1,
					"id"		=> $row->id,
					"date"		=> $row->date,
					"time"		=> $row->time,
					"voltage"	=> $row->voltage
				);
				$i++;
			}
			$jsonResult .= json_encode($json_data);
			$jsonResult .= '}';

			return $jsonResult;
		}

		function get_data_chart($data,$value){
			$tmpLabels = array();
			$tmpDatas = array();
			$no = 0;
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC LIMIT $value");

			foreach($query->result() as $row){
				$tmpLabels[$no] = $row->date." ".$row->time; 
				$tmpDatas[$no] = $row->voltage;
				$no++;
			}

			$mdata = '[';

			if($data == "labels"){
				for($x=$value-1;$x>=0;$x--){
					$mdata .= '"'.$tmpLabels[$x].'",';	
				}
			}
			else if($data == "datas"){
				for($x=$value-1;$x>=0;$x--){
					$mdata .= $tmpDatas[$x].',';
				}
			}

			$mdata .= ']';

			return $mdata;
		}

		//disabled
		function get_data_line($value){
			$tmpLabels = array();
			$tmpDatas = array();
			$no = 0;
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC LIMIT $value");
			foreach($query->result() as $row){
				$tmpLabels[$no] = $row->date." ".$row->time;
				$tmpDatas[$no] = $row->voltage;
				$no++;
			}

			$mdataLabels = '[';
			for($x=$value-1;$x>=0;$x--){
				$mdataLabels .= '"'.$tmpLabels[$x].'",';
			}
			$mdataLabels .= ']';

			$mdataDatas = '[';
			for($x=$value-1;$x>=0;$x--){
				$mdataDatas .= $tmpDatas[$x].',';
			}
			$mdataDatas .= ']';

			$data = array(
				'labels' => $mdataLabels,
				'datas' => $mdataDatas
			);

			return $data;
		}

	}