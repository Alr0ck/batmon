<?php

	class M_battery extends CI_Model{

		function add_data($table,$data){
			$this->db->insert($table,$data);
		}

		function update_maxvoltage($id,$data){
			$this->db->where('id',$id);
			$this->db->update('setting',$data);
		}

		function get_max_voltage(){
			$data = array();
			$query = $this->db->query("SELECT * FROM setting WHERE id = 1");
			foreach($query->result() as $row){
				$data[0] = $row->maxvoltage;
			}
			return $data;
		}

		function update_data_temporary($id_battery,$data){
			$check = $this->db->query("SELECT * FROM temporary WHERE id_battery = '$id_battery'");
			if(!$check->num_rows()){
				$this->db->insert('temporary',$data);
			}

			$this->db->where('id_battery',$id_battery);
			$this->db->update('temporary',$data);
		}

		function grab_data(){
			$data = array();
			$query = $this->db->query("SELECT * FROM temporary ORDER BY id ASC");
			foreach($query->result() as $row){
				$id_battery = $row->id_battery;
				$date 		= $row->date;
				$time		= $row->time;
				$voltage	= $row->voltage;
				$precentage	= $row->precentage;

				$data = array(
					'id_battery'	=> $id_battery,
					'date'			=> $date,
					'time'			=> $time,
					'voltage' 		=> $voltage,
					'precentage' 	=> $precentage
				);

				$query2 = $this->db->query("SELECT * FROM data2 WHERE id_battery = '$id_battery'");
				foreach($query2->result() as $row2){
					if($row2->time != $time){
						$this->db->insert('data',$data);
					}
				}

				$this->db->where('id_battery',$id_battery);
				$this->db->update('data2',$data);
			}
		}

		function get_data_monitor(){
			$i = 0;
			$data = array();
			$query = $this->db->query("SELECT * FROM data2 ORDER BY id ASC");
			$jsonResult = '{"data" : ';
			foreach($query->result() as $row){

				$percent = $row->precentage;

				if($percent <= 20){
					$status = '<div class="progress-bar progress-bar-danger" role="progressbar" style="width:'.$percent.'%" >'.$percent.'%</div>';
				}
				else if($percent <= 60){
					$status = '<div class="progress-bar progress-bar-warning" role="progressbar" style="width:'.$percent.'%" >'.$percent.'%</div>';
				}
				else if($percent <= 100){
					$status = '<div class="progress-bar progress-bar-success" role="progressbar" style="width:'.$percent.'%" >'.$percent.'%</div>';
				}

				$json_data[$i] = array(
					"no"			=> $i+1,
					"id"			=> $row->id,
					"id_battery"	=> $row->id_battery,
					"date"			=> $row->date,
					"time"			=> $row->time,
					"voltage"		=> $row->voltage,
					"precentage" 	=> $percent,
					"detail"		=> '<a href="'.base_url()."battery/detail?id=".$row->id_battery.'"><button class="btn btn-warning btn-sm">Battery_'.$row->id_battery.'</button></a>',
					"status"		=> $status
				);
				$i++;
			}
			$jsonResult .= json_encode($json_data);
			$jsonResult .= '}';

			return $jsonResult;
		}

		function get_data_detail($id_battery){
			$i = 0;
			$data = array();
			$query = $this->db->query("SELECT * FROM data WHERE id_battery = '$id_battery' ORDER BY id ASC ");
			$jsonResult = '{"data" : ';
			foreach($query->result() as $row){

				$percent = $row->precentage;

				if($percent <= 20){
					$status = '<div class="progress-bar progress-bar-danger" role="progressbar" style="width:'.$percent.'%" >'.$percent.'%</div>';
				}
				else if($percent <= 60){
					$status = '<div class="progress-bar progress-bar-warning" role="progressbar" style="width:'.$percent.'%" >'.$percent.'%</div>';
				}
				else if($percent <= 100){
					$status = '<div class="progress-bar progress-bar-success" role="progressbar" style="width:'.$percent.'%" >'.$percent.'%</div>';
				}

				$json_data[$i] = array(
					"no"			=> $i+1,
					"id"			=> $row->id,
					"id_battery"	=> $row->id_battery,
					"date"			=> $row->date,
					"time"			=> $row->time,
					"voltage"		=> $row->voltage,
					"precentage" 	=> $percent,
					"status"		=> $status
				);
				$i++;
			}
			$jsonResult .= json_encode($json_data);
			$jsonResult .= '}';

			return $jsonResult;
		}

        //Add Data Hardware

		function get_data_location(){
			$i = 0;
			$data = array();
			$query = $this->db->query("SELECT * FROM location ORDER BY id ASC");
			$jsonResult = '{"data" : ';
			foreach($query->result() as $row){
				$id 		= $row->id;
				$id_battery = $row->id_battery;
				$latitude 	= $row->latitude;
				$longitude 	= $row->longitude;

				$json_data[$i] = array(
					"no"			=> $i+1,
					"id"			=> $id,
					"id_battery"	=> $id_battery,
					"latitude"		=> $latitude,
					"longitude"		=> $longitude,
					"action"		=> '<a href="'.base_url()."battery/location?id=".$row->id_battery.'"><button class="btn btn-info btn-sm">Location</button></a>&nbsp;'.'<a href="'.base_url()."battery/edit?id=".$row->id_battery.'"><button class="btn btn-warning btn-sm">Edit</button></a>&nbsp;'.'<a href="'.base_url()."battery/delete?id=".$row->id_battery.'"><button class="btn btn-danger btn-sm">Delete</button></a>'
				);
				$i++;
			}
			$jsonResult .= json_encode($json_data);
			$jsonResult .= '}';

			return $jsonResult;
		}
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		function get_data_latest(){
			$data = array();
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC LIMIT 1");
			foreach($query->result() as $row){
				$data[0] = $row->id;
				$data[1] = $row->date;
				$data[2] = $row->time;
				$data[3] = $row->voltage;
				$data[4] = $row->isdeleted;
			}
			return $data;
		}

		function get_data_all(){
			$i = 0;
			$data = array();
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC");
			
			$jsonResult = '{"data" : ';
			foreach($query->result() as $row){
				$json_data[$i] = array(
					"no"		=> $i+1,
					"id"		=> $row->id,
					"date"		=> $row->date,
					"time"		=> $row->time,
					"voltage"	=> $row->voltage
				);
				$i++;
			}
			$jsonResult .= json_encode($json_data);
			$jsonResult .= '}';

			return $jsonResult;
		}

		function get_data_chart($data,$value){
			$tmpLabels = array();
			$tmpDatas = array();
			$no = 0;
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC LIMIT $value");

			foreach($query->result() as $row){
				$tmpLabels[$no] = $row->date." ".$row->time; 
				$tmpDatas[$no] = $row->voltage;
				$no++;
			}

			$mdata = '[';

			if($data == "labels"){
				for($x=$value-1;$x>=0;$x--){
					$mdata .= '"'.$tmpLabels[$x].'",';	
				}
			}
			else if($data == "datas"){
				for($x=$value-1;$x>=0;$x--){
					$mdata .= $tmpDatas[$x].',';
				}
			}

			$mdata .= ']';

			return $mdata;
		}

		//disabled
		function get_data_line($value){
			$tmpLabels = array();
			$tmpDatas = array();
			$no = 0;
			$query = $this->db->query("SELECT * FROM data ORDER BY id DESC LIMIT $value");
			foreach($query->result() as $row){
				$tmpLabels[$no] = $row->date." ".$row->time;
				$tmpDatas[$no] = $row->voltage;
				$no++;
			}

			$mdataLabels = '[';
			for($x=$value-1;$x>=0;$x--){
				$mdataLabels .= '"'.$tmpLabels[$x].'",';
			}
			$mdataLabels .= ']';

			$mdataDatas = '[';
			for($x=$value-1;$x>=0;$x--){
				$mdataDatas .= $tmpDatas[$x].',';
			}
			$mdataDatas .= ']';

			$data = array(
				'labels' => $mdataLabels,
				'datas' => $mdataDatas
			);

			return $data;
		}

	}